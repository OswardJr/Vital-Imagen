-- # A Mysql Backup System
-- # Export created: 2017/06/26 on 10:30
-- # Database : clinica
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `citas`
DROP TABLE  IF EXISTS `citas`;
CREATE TABLE `citas` (
  `id_citas` int(11) NOT NULL AUTO_INCREMENT,
  `ced_paciente` int(11) NOT NULL,
  `id_doctor` int(11) NOT NULL,
  `fecha_cita` date NOT NULL,
  `motivo` text COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id_citas`),
  KEY `id_paciente` (`ced_paciente`),
  KEY `id_doctor` (`id_doctor`),
  CONSTRAINT `citas_ibfk_3` FOREIGN KEY (`id_doctor`) REFERENCES `doctores` (`id_doctor`) ON UPDATE CASCADE,
  CONSTRAINT `citas_ibfk_4` FOREIGN KEY (`ced_paciente`) REFERENCES `pacientes` (`ced_paciente`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `citas` (`id_citas`, `ced_paciente`, `id_doctor`, `fecha_cita`, `motivo`) VALUES (1, 24924739, 6, '2017-08-21', 'Dolor de Espalda'), 
(2, 24924739, 7, '2017-06-15', 'Dolor de Muela');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
