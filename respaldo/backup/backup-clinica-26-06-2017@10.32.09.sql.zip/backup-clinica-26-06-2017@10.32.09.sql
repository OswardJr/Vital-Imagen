-- # A Mysql Backup System
-- # Export created: 2017/06/26 on 10:32
-- # Database : clinica
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `pacientes`
DROP TABLE  IF EXISTS `pacientes`;
CREATE TABLE `pacientes` (
  `ced_paciente` int(11) NOT NULL,
  `primer_nombre` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `segundo_nombre` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `primer_apellido` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `segundo_apellido` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `edad` int(50) NOT NULL,
  `direccion` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `telefono` int(100) NOT NULL,
  `ocupacion` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `responsable` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `status` enum('activo','inactivo','','') COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`ced_paciente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

INSERT INTO `pacientes` (`ced_paciente`, `primer_nombre`, `segundo_nombre`, `primer_apellido`, `segundo_apellido`, `fecha_nacimiento`, `edad`, `direccion`, `telefono`, `ocupacion`, `responsable`, `status`) VALUES (24924739, 'Leoncio', 'Enrique', 'Requena', 'Gonzalez', '1995-08-14', 21, 'Vista Hermosa', 426331232, 'Programador Web', 'Omaira', 'activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
